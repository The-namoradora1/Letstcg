

const Carrossa = [
  {
    id: 1,
    image: require('./Banner/1.jpg'),
    alt: "Imagem 1"
  },
  {
    id: 2,
    image: require('./Banner/2.jpg'),
    alt: "Imagem 2"
  },
  {
    id: 3,
    image: require('./Banner/3.jpg'),
    alt: "Imagem 3"
  },

];
export default Carrossa;