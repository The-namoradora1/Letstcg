// import { Text, TextInput, View} from "react-native-web";
// import styles from "./stilo.js";

// export default function Cartaz(){

//   return       <Text style={styles.textBanner}>Em Cartaz</Text>


// }