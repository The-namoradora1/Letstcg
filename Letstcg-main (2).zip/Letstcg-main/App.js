import React from 'react';
import Rotas from './src/rotas/index.js';

export default function App() {
  return (
  
  <Rotas></Rotas>
  
  );
}
